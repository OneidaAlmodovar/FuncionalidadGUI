/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package registromaestros;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author a227215
 */
//implementamos la interfaz Runnable para nuestro Hilo
public class FechaHora implements Runnable{
    
    //declaramos un metodo statico que nos muestra la hora y fecha actual
    public static String hora(){
        Date hora = new Date();
        String pmAm = "dd/MM/YYYY hh:mm:ss a";
        SimpleDateFormat formatoHora = new SimpleDateFormat(pmAm);
        return formatoHora.format(hora);
    }
    //sobreescribimos el método run de la interfaz Runnable y lo adaptamos a nuestra necesidades que es mostrar la hora en nuestro lblFechaHora mediante el metodo hora() de nuestra clase FechHora
    @Override
    public void run() {
        Thread current = Thread.currentThread();
        while(current == VentanaPrincipal.hilo2){
            try {
                //dormimos el hilo un segundo para que muestre la hora cada segundo.
                Thread.sleep(1000);
            } catch (InterruptedException ex) {
                Logger.getLogger(VentanaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            }
            VentanaPrincipal.lblFechaHora.setText(hora());
        }
        
    }
    
}
