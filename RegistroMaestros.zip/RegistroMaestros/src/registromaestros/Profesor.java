/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package registromaestros;

/**
 *
 * @author a227215
 */
public class Profesor {
    //atributos de nuestro profesor
    private String numeroControl;
    private String nombreCompleto;
    private int id;
    private boolean  asistencia;
    
    //constructor de nuestra clase Profesor que se pide 4 paramatros para constuir nuestra clase
    public Profesor(int id,String numeroControl,String nombreCompleto, boolean asistencia){
        this.id = id;
        this.numeroControl = numeroControl;
        this.nombreCompleto = nombreCompleto;
        this.asistencia = asistencia;
        
    }
    //getter y setter de nuestrs atributos
    public void setAsistencia(boolean asistencia) {
        this.asistencia = asistencia;
    }

    public boolean isAsistencia() {
        return asistencia;
    }
    
    public void setId(int id) {
        this.id = id;
    }

    public void setNumeroControl(String numeroControl) {
        this.numeroControl = numeroControl;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public int getId() {
        return id;
    }

    public String getNumeroControl() {
        return numeroControl;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }
    
    
}
