/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package registromaestros;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author a227215
 */
public class ListaAsistencia {
    //Total de profesores en la basde de datos
    public static int totalProfesores;
    //total de profesores registrados en la asistencia
    public static int asistenciaProfesores;
    //´porcentaje de profesores 
    public static int porcentaje = 0;
    	
    //guardamos el ID del profesor para saber si ya existe en nuestra asistencia
    public static List <Integer> profesoresRegistradosAsistencia = new ArrayList<Integer>();
    
    //se hizó una lista de la Clase Profesor para guardar nuestros profesores de la base de datos para posterior hacer validaciones así como guardarlos en un archivo de excel.
    public static List <Profesor> Profesores = new ArrayList<Profesor>();
    
}
