<?php
	require 'conexion.php';
		//verificamos si existe la variable idProfesor
	if (isset($_GET["idProfesor"])) {
		$db = Singleton::getConnect()::$connection;
		//guardamos la consulta en una variable
		$consulta = "SELECT ID,Numero_Control,Nombre_Completo FROM profesores WHERE Numero_Control = '".$_GET["idProfesor"]."' OR Nombre_Completo = '".$_GET["idProfesor"]."'";
		$resultado = $db->query($consulta);
		//si el resultado es mayor a cero quiere decir que si existe el profesor
		if ($resultado->num_rows > 0) {
			while($fila = $resultado->fetch_assoc())
		    {
		    	$arregloProfesores [] = $fila;
		    }
		}
		else{
			//sino existe mandamos vacio el JSON
			$arregloProfesores [] = "";
		}
		//imprimimos en pantalla nuestra json
	   echo json_encode($arregloProfesores,JSON_UNESCAPED_UNICODE);
	}
 ?>