<?php
/**
 *Este patrón simplemente restringe la instanciación de una clase a un objeto. Es útil cuando se necesita exactamente un objeto para coordinar las acciones en la aplicación. A menudo es utilizado en situaciones en las que no es beneficioso, ya que añade restricciones innecesarias.
 */
class Singleton
{
  //atributos de nuestra clase
  public static $connection;
  private $dbHost;
  private $dbUser;
  private $dbPassword;
  private $nombreDb;
  private static $instance;

  //constructor
  private function __construct()
  {
    //variables que usa para la conexión para la base de datos en mariadb
    //ip o nombre donde esta  nuestra base de datos
    $dbHost = "108.178.57.18";
    //nombre usuario
    $dbUser = "zdcxgluy_root";
    //contraseña
    $dbPassword = "alejandra123";
    //nombre base de datos
    $nombreDb = "zdcxgluy_reunion";
    //hace una instancia de la clase mysqli con los parametros que necesita.
    self::$connection = new mysqli($dbHost,$dbUser,$dbPassword,$nombreDb);
    //si hay un error en la conexión a la base de datos mostramos el error en pantalla y ver porque sucedio el error.
    if (self::$connection->connect_errno) {
      echo "Fallo al conectar a mysql". self::$connection->connect_error;
      return;
    }else {
      //permitimos que los caracteres manejados en la conexión sean utf8
      self::$connection->set_charset("utf8");
    }
  }
  //función conexion que retorna la conexión de la base de datos.
  public static function getConnect(){
    if (!isset(self::$instance)) {
      self::$instance = new Singleton;
    }
    else {
      echo "conexión ya iniciada";
    }
    return self::$instance;
  }
}

 ?>
