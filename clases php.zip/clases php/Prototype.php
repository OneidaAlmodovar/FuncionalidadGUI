<?php
/**
 * Patrón de diseño Prototype
  La gran ventaja de esto es que el tiempo necesario para replicar un objeto es mucho menor que el tiempo que se tarda en crear una nueva instancia y establecer los nuevos valores.
  Se usaría el patron de diseño Prototipe nos permite encapsular nuestra variables y solo usar las funciones que necesitamos.
 */
class Prototype
{
  //constructor
  function __construct()
  {

  }
  //función conexion que retorna la conexión de la base de datos.
  public function conexion()
  {
    //variables que usa para la conexión para la base de datos en mariadb
    //ip o nombre donde esta  nuestra base de datos
    $dbHost = "108.178.57.18";
    //nombre usuario
    $dbUser = "zdcxgluy_root";
    //contraseña
    $dbPassword = "alejandra123";
    //nombre base de datos
    $nombreDb = "zdcxgluy_reunion";
    //hace una instancia de la clase mysqli con los parametros que necesita.
    $connection = new mysqli($dbHost,$dbUser,$dbPassword,$nombreDb);
    //si hay un error en la conexión a la base de datos mostramos el error en pantalla y ver porque sucedio el error.
    if ($connection->connect_errno) {
      echo "Fallo al conectar a mysql". $connection->connect_error;
      return;
    }else {
      //permitimos que los caracteres manejados en la conexión sean utf8
      $connection->set_charset("utf8");
    }
    //regreamos la variable $conexión.
    return $connection;
  }
}
 ?>
