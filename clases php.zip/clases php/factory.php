<?php
/**
 * Creamos una interfaz llamada Factory con un metodo llamado conectar.
 El Factory pattern define una interfaz para crear un objeto, pero deja a las subclases decidir que clase instanciar. Este patrón permite a una clase ceder la instanciación a las subclases.
 */
interface Factory
{
    public function conectar();
}

/**
 * Implementamos nuestra interfaz Factory y sobreescribimos el método conectar en nuestra clase Conexion.
 */
class Conexion implements Factory
{
  //constructor
  function __construct()
  {
  }
  //sobreescribimos nuestra funcion conectar y retorna la conexion a la base de datos.
  public function conectar()
  {
    //variables que usa para la conexión para la base de datos en mariadb
    //ip o nombre donde esta  nuestra base de datos
    $dbHost = "108.178.57.18";
    //nombre usuario
    $dbUser = "zdcxgluy_root";
    //contraseña
    $dbPassword = "alejandra123";
    //nombre base de datos
    $nombreDb = "zdcxgluy_reunion";
    //hace una instancia de la clase mysqli con los parametros que necesita.
    $connection = new mysqli($dbHost,$dbUser,$dbPassword,$nombreDb);
    //si hay un error en la conexión a la base de datos mostramos el error en pantalla y ver porque sucedio el error.
    if ($connection->connect_errno) {
      echo "Fallo al conectar a mysql". $connection->connect_error;
      return;
    }else {
      //permitimos que los caracteres manejados en la conexión sean utf8
      $connection->set_charset("utf8");
    }
    //regresamos la variable $connection
    return $connection;
  }

}
 ?>
