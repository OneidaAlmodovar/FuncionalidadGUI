<?php
	require 'conexion.php';
	//verificamos si existe la variable numeroControl y nombreComplero
	if (isset($_GET["numeroControl"]) && isset($_GET["nombreCompleto"])) {
		$db = Singleton::getConnect()::$connection;
		//guardamos la consulta en una variable
		$consulta = "INSERT INTO `profesores` (`ID`, `Numero_Control`, `Nombre_Completo`) VALUES (NULL, '".strtoupper($_GET["numeroControl"])."', '".strtoupper($_GET["nombreCompleto"])."')";
		//ejecutamos nuestra consulta
		$resultado = $db->query($consulta);
		//si resultado es false quiere decir que hubo error al insertar en la base de datos
		if (!$resultado) {
			$arregloProfesores["validacion"] = "error";
			$arregloProfesores['datos']=$db->errno."($db->error)";
		}else{
			//si se inserto mandamos un mensaje de exito
			$arregloProfesores["validacion"] = "exito";
		}
		//imprimimos en pantalla nuestra json
		echo json_encode($arregloProfesores,JSON_UNESCAPED_UNICODE);
	}
 ?>