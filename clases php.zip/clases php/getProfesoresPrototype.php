<?php
	//solicitamos que llame lo que tiene el archivo Prototipo.php
	require 'Prototype.php';
	//hacemos una instancia de nuestra clase Prototype
	$objecto = new Prototype;
	//llamamos a la función conexion y la guardamos en la variable $db
	$db = $objecto->conexion();
	//guardamos nuestra consulta en la variable $consulta
	$consulta = "select * from profesores";
	//ejecutamos nuestro query a la base de datos. y guardamos el resultado en la variable $resultado
	$resultado = $db->query($consulta);
	//si la cantidad de filas obtenidas es mayor a cero recorremos con un while las filas obtenidas en la variable $resultado mediante la función fetch_assoc(), si no se cumple con la condición entonces mandamos el arreglo vacio para indicar que no se obtuvo ningún registro de la consulta.
	if ($resultado->num_rows > 0) {
		//recorremos las filas extraidas de nuestra consulta con un while y guardamos en un arreglo cada fila obtenida de nuestra conexión
		while($fila = $resultado->fetch_assoc())
		{
			//guardamos en nuestro arreglo cada registro encontrado de nuestra consulta
			$arregloProfesores [] = $fila;
		}
	}
	else{
		//guardamos en nuestro arreglo una cadena vacia para indicar que la consulta realizada a la base de datos no 
		$arregloProfesores [] = "";
	}
	//con la funcion json_encode tranformamos nuestro arreglo en formato JSON. La palabra reservada echo nos permite mostrar el contenido de variables y cadenas de texto, en nuestro caso vamos a mostrar el JSON de nuestra consulta.
	echo json_encode($arregloProfesores,JSON_UNESCAPED_UNICODE);
 ?>
